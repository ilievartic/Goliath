class BadReplyException(Exception):
    pass

class NoWorkerResult(Exception):
    pass